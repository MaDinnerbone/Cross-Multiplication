# Cross-Multiplication
cross multiplication 

## WHAT IS CROSS MULTIPLICATION?

## The method of cross multiplication is simply:

### the product of the left side of the cross is the quadratic term, 
###     the product of the right side is the constant term, 
###     and the cross multiplication is equal to the first term. 
###     The idea is to use the inverse of binomial multiplication to factor

## Options:

###     This program is designed for cross multiplication factorization and can ONLY input positive integers!!!

# THIS IS FOR CHINESE PEOPLE TO READ:
# 下面的内容是给中国人看的:

# 什么是十字相乘法?

## 十字相乘法的方法简单来讲就是：

###     十字左边相乘的积为二次项，
###     右边相乘的积为常数项，
###     交叉相乘再相加等于一次项。
###     原理就是运用二项式乘法的逆运算来进行因式分解

## 注意:

###     这个程序是给十字相乘因式分解设计的,而且!!!只能!!!输入正整数!!!
